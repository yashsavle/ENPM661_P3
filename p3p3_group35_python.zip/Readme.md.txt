This gives the instructions to run python program for navigation of the turtlebot using Astar with holonomic constraints

For the video provided the inputs were initialized but will have to be provided when you run the code


The initialized inputs for video 1 are
Enter x of start co-ordinates:4.5
Enter y of start co-ordinates:4.5
Enter theta of start co-ordinates:0
Enter x of Goal co-ordinates:-4.5
Enter y of Goal co-ordinates:-4.5
Enter left wheel speed:36
Enter right wheel speed:-27
Enter clearance value: 45

The minus speed for right wheel tells that the robot can even go back and also the robot can rotate with a bigger raduis of curvature than with only positive speeds
making almost any configuration possible to reach.

Instructions to run the code
1. Extract the files into a directory
2. in a terminal run 
chmod +x withRPMs_new_maze.py
python3 withRPMs_new_maze.py

Provide the parameters you want or the ones given above to simulate the above given cases
Also after a red line appears on the window where exploration is going on, means that the path planning has completed. You have to press any key on the keyboard to proceed. After this watch the turtlebot track the path found.

 


