This gives the instructions to run the ros program for navigation of the turtlebot using Astar with holonomic constraints

For the video provided the inputs were initialized but will have to be provided when you run the code

The initialized inputs for video 2 are
Enter x of start co-ordinates:4.5
Enter y of start co-ordinates:4.5
Enter theta of start co-ordinates:0
Enter x of Goal co-ordinates:-4.5
Enter y of Goal co-ordinates:-2.5
Enter left wheel speed:36
Enter right wheel speed:-27

